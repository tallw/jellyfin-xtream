Project based on the repository [Link](https://github.com/Kevinjil/Jellyfin.Xtream), where I made some changes for personal use. All rights reserved to the project repository above.

